import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunner12 {
	
	public static void main(String[] args){
		
		
		
	}

}
